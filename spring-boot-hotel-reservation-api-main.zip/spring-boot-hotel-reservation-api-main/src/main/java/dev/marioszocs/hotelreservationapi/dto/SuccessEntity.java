package dev.marioszocs.hotelreservationapi.dto;

import lombok.Data;

@Data
public class SuccessEntity {
    private boolean success;
}
