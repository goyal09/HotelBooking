package dev.marioszocs.hotelreservationapi.utils;

public class AppUtils {
}
