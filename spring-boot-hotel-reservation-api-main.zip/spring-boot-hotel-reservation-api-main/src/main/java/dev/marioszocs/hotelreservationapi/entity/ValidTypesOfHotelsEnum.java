package dev.marioszocs.hotelreservationapi.entity;

public enum ValidTypesOfHotelsEnum {
    DELUXE, LUXURY, SUITE
}
