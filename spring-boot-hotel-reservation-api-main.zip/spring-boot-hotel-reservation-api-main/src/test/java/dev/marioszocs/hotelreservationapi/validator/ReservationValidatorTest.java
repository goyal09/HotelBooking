package dev.marioszocs.hotelreservationapi.validator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReservationValidatorTest {

    @Test
    void validateReservationPOST() {
    }

    @Test
    void validateId() {
    }

    @Test
    void validateDates() {
    }

    @Test
    void validateGuest() {
    }
}