package dev.marioszocs.hotelreservationapi.dto;

import lombok.Data;

@Data
public class IdEntity {
    private Integer id;

}
